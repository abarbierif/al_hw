//Numpy array shape [10]
//Min -0.341304600239
//Max 0.306837737560
//Number of zeros 0

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
output_bias_t b15[10];
#else
output_bias_t b15[10] = {-0.3413046002, -0.0465366729, 0.0482286736, -0.3381358683, 0.0728105679, 0.3068377376, 0.1357094944, -0.0243507866, 0.0465557985, 0.2302759439};
#endif

#endif
