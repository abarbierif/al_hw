//Numpy array shape [10]
//Min -0.061413455755
//Max 0.089625366032
//Number of zeros 0

#ifndef B23_H_
#define B23_H_

#ifndef __SYNTHESIS__
output_bias_t b23[10];
#else
output_bias_t b23[10] = {-0.0486874841, -0.0434977561, -0.0307688918, -0.0614134558, 0.0786340460, 0.0239779316, 0.0896253660, -0.0226715561, 0.0275271889, -0.0034193515};
#endif

#endif
